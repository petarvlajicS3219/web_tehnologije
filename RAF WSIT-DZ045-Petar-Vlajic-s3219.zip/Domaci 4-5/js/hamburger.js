function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }